// Variation 4 — Experimental: AI-first spatial map of deals × people × firms
// Companies as glowing nodes sized by check, connected to founders + co-investors.
// Sidebar shows the AI's running brief; bottom bar is a global ask.

function V4Spatial() {
  // Node positions in canvas coords (root canvas is ~840×560)
  const nodes = [
    { id:'lattice',   x: 380, y: 200, r: 56, deal: DEALS[0], stage:'ic',        glow:'#ff2d92' },
    { id:'parallel',  x: 200, y: 130, r: 36, deal: DEALS[2], stage:'firstcall', glow:'#5b8def' },
    { id:'verdant',   x: 560, y: 110, r: 40, deal: DEALS[1], stage:'diligence', glow:'#22c08a' },
    { id:'cipher',    x: 660, y: 290, r: 50, deal: DEALS[4], stage:'termsheet', glow:'#a26bff' },
    { id:'qubit',     x: 240, y: 360, r: 30, deal: DEALS[5], stage:'sourced',   glow:'#ef4444' },
    { id:'northstar', x: 120, y: 240, r: 28, deal: DEALS[3], stage:'sourced',   glow:'#76767c' },
    { id:'orbital',   x: 520, y: 420, r: 32, deal: DEALS[6], stage:'closed',    glow:'#ff8a3d' },
  ];
  const byId = Object.fromEntries(nodes.map(n => [n.id, n]));

  // Edges: solid = co-investor / shared lead; dashed = founder relationship
  const edges = [
    { a:'lattice',  b:'cipher',   kind:'solid', label:'Sequoia co-invest' },
    { a:'lattice',  b:'parallel', kind:'dashed', label:'Both ex-Anthropic' },
    { a:'verdant',  b:'lattice',  kind:'solid', label:'a16z co-invest' },
    { a:'parallel', b:'orbital',  kind:'dashed', label:'YC W26' },
    { a:'cipher',   b:'orbital',  kind:'solid', label:'Sequoia' },
    { a:'qubit',    b:'lattice',  kind:'dashed', label:'CMU alumni' },
    { a:'northstar',b:'verdant',  kind:'dashed', label:'Health crossover' },
  ];

  return (
    <div className="orb" style={{ width: 1280, height: 800, position:'relative', overflow:'hidden' }}>
      <TopNav active="dealflow" />

      <div style={{ position:'absolute', top: 44, left: 0, right: 0, bottom: 0,
                    display:'grid', gridTemplateColumns: '232px 1fr 280px' }}>

        {/* Left rail */}
        <div className="orb-rail">
          <div className="orb-rail-head">Deal Flow</div>
          <div className="orb-search">Search deals…</div>
          <div className="orb-rail-list" style={{ paddingTop: 4 }}>
            <div style={{ padding:'8px 12px 4px', fontSize: 10, color:'var(--text-4)',
              textTransform:'uppercase', letterSpacing:'.08em', fontWeight: 600 }}>Layouts</div>
            <div className="orb-row" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--text-3)' }}>≡</span>
              <span className="title" style={{ fontSize: 12.5, color:'var(--text-2)' }}>List</span>
              <span/>
            </div>
            <div className="orb-row" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--text-3)' }}>▦</span>
              <span className="title" style={{ fontSize: 12.5, color:'var(--text-2)' }}>Board</span>
              <span/>
            </div>
            <div className="orb-row is-active" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--magenta)' }}>✦</span>
              <span className="title" style={{ fontSize: 12.5, color:'#fff', fontWeight: 600 }}>Constellation</span>
              <span style={{ fontSize:9.5, color:'var(--magenta)' }}>BETA</span>
            </div>

            <div style={{ padding:'14px 12px 4px', fontSize: 10, color:'var(--text-4)',
              textTransform:'uppercase', letterSpacing:'.08em', fontWeight: 600 }}>Lens</div>
            <Lens active label="Co-investor graph" />
            <Lens label="Founder relationships" />
            <Lens label="Sector heat" />
            <Lens label="Check size weight" />
            <Lens label="Time to close" />

            <div style={{ padding:'14px 12px 4px', fontSize: 10, color:'var(--text-4)',
              textTransform:'uppercase', letterSpacing:'.08em', fontWeight: 600 }}>People</div>
            {PEOPLE.slice(0,4).map(p => (
              <div key={p.name} className="orb-row" style={{ gridTemplateColumns:'24px 1fr auto', padding: '7px 10px' }}>
                <div style={{ width: 22, height: 22, borderRadius: '50%',
                  background: p.color, fontSize: 10, fontWeight: 700, color:'#fff',
                  display:'inline-flex', alignItems:'center', justifyContent:'center' }}>{p.initials}</div>
                <div>
                  <div className="title" style={{ fontSize: 12 }}>{p.name}</div>
                  <div className="meta">{p.role}</div>
                </div>
                {p.hot && <span style={{ width: 5, height: 5, borderRadius:3, background:'var(--hot)',
                  boxShadow:'0 0 6px var(--hot)' }} />}
              </div>
            ))}
          </div>
        </div>

        {/* Spatial canvas */}
        <div style={{ position:'relative', overflow:'hidden',
          background: 'radial-gradient(80% 60% at 50% 45%, rgba(255,45,146,.08), transparent 60%), #050507' }}>
          {/* Grid bg */}
          <div style={{ position:'absolute', inset: 0,
            backgroundImage: 'radial-gradient(rgba(255,255,255,.05) 1px, transparent 1px)',
            backgroundSize: '24px 24px', maskImage: 'radial-gradient(60% 60% at 50% 50%, #000, transparent)' }} />

          {/* Toolbar */}
          <div style={{ position:'absolute', top: 14, left: 18, right: 18, display:'flex', gap: 10, zIndex: 5 }}>
            <div style={{ display:'flex', gap: 4, padding: 3, borderRadius: 8, background:'var(--surface-1)', border:'1px solid var(--line)' }}>
              <Tab label="Board" />
              <Tab label="Table" />
              <Tab label="Calendar" />
              <Tab active label="Map" />
            </div>
            <div style={{ flex: 1 }} />
            <span className="orb-pill"><span className="dot" style={{ background:'var(--magenta)' }} />7 active</span>
            <span className="orb-pill">Co-invest edges: 4</span>
            <span className="orb-pill" style={{ color:'var(--magenta)', borderColor:'rgba(255,45,146,.3)' }}>+ Add deal</span>
          </div>

          {/* SVG graph */}
          <svg viewBox="0 0 840 560" preserveAspectRatio="xMidYMid meet"
            style={{ position:'absolute', inset: 40, width:'calc(100% - 80px)', height:'calc(100% - 180px)' }}>
            <defs>
              <radialGradient id="haze" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ff2d92" stopOpacity=".55" />
                <stop offset="50%" stopColor="#6b1f9a" stopOpacity=".25" />
                <stop offset="100%" stopColor="#000" stopOpacity="0" />
              </radialGradient>
              {nodes.map(n => (
                <radialGradient key={n.id} id={`g-${n.id}`} cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor={n.glow} stopOpacity=".9" />
                  <stop offset="60%" stopColor={n.glow} stopOpacity=".15" />
                  <stop offset="100%" stopColor={n.glow} stopOpacity="0" />
                </radialGradient>
              ))}
              <filter id="soft"><feGaussianBlur stdDeviation="0.6"/></filter>
            </defs>

            {/* Edges */}
            {edges.map((e, i) => {
              const a = byId[e.a], b = byId[e.b];
              return (
                <g key={i} opacity=".55">
                  <line x1={a.x} y1={a.y} x2={b.x} y2={b.y}
                    stroke={e.kind === 'solid' ? 'rgba(255,255,255,.35)' : 'rgba(255,255,255,.18)'}
                    strokeWidth={e.kind === 'solid' ? 1.2 : 1}
                    strokeDasharray={e.kind === 'dashed' ? '3 4' : ''} />
                  <text x={(a.x+b.x)/2} y={(a.y+b.y)/2 - 4}
                    fontFamily="Inter Tight, system-ui" fontSize="9"
                    fill="rgba(255,255,255,.4)" textAnchor="middle">{e.label}</text>
                </g>
              );
            })}

            {/* Nodes — glow */}
            {nodes.map(n => (
              <circle key={`h-${n.id}`} cx={n.x} cy={n.y} r={n.r * 2.6}
                fill={`url(#g-${n.id})`} />
            ))}

            {/* Nodes — body */}
            {nodes.map(n => (
              <g key={n.id} transform={`translate(${n.x},${n.y})`}>
                <circle r={n.r} fill="#0c0c10" stroke={n.glow} strokeOpacity=".5" />
                <circle r={n.r - 1} fill="url(#haze)" opacity={n.deal.temp === 'hot' ? .9 : .35} />
                <text y={3} fontFamily="Inter Tight, system-ui" fontSize={n.r * 0.5}
                  fontWeight="700" fill="#fff" textAnchor="middle">{n.deal.mark}</text>
                <text y={n.r + 14} fontFamily="Inter Tight, system-ui" fontSize="11"
                  fontWeight="600" fill="#fff" textAnchor="middle">{n.deal.name}</text>
                <text y={n.r + 26} fontFamily="Inter Tight, system-ui" fontSize="9"
                  fill="rgba(255,255,255,.5)" textAnchor="middle">
                  {STAGES.find(s=>s.id===n.stage)?.label} · {n.deal.raising}
                </text>
              </g>
            ))}
          </svg>

          {/* Legend bottom-left */}
          <div style={{ position:'absolute', bottom: 100, left: 18, display:'flex', gap: 14,
            fontSize: 11, color:'var(--text-3)' }}>
            <span style={{ display:'inline-flex', alignItems:'center', gap: 6 }}>
              <span style={{ width: 16, height: 1, background:'rgba(255,255,255,.4)' }}/>
              Co-investor
            </span>
            <span style={{ display:'inline-flex', alignItems:'center', gap: 6 }}>
              <span style={{ width: 16, height: 1, background:'rgba(255,255,255,.25)',
                backgroundImage:'repeating-linear-gradient(90deg,rgba(255,255,255,.4) 0 3px,transparent 3px 7px)' }}/>
              Founder link
            </span>
            <span style={{ display:'inline-flex', alignItems:'center', gap: 6 }}>
              <span style={{ width: 8, height: 8, borderRadius:4, background:'var(--hot)',
                boxShadow:'0 0 6px var(--hot)' }}/>
              Hot deal
            </span>
            <span style={{ color:'var(--text-4)' }}>Node size = check $</span>
          </div>

          {/* Footer ask bar */}
          <div style={{ position:'absolute', left: 18, right: 18, bottom: 22 }}>
            <AskBar placeholder="Ask Orbiter — “Show me where Sequoia and a16z overlap in our pipeline”" />
          </div>
        </div>

        {/* Right AI brief panel */}
        <div style={{ borderLeft:'1px solid var(--line)', display:'flex', flexDirection:'column', minHeight: 0 }}>
          <div style={{ padding:'14px 16px 10px', display:'flex', alignItems:'center', gap: 8,
            borderBottom:'1px solid var(--line)' }}>
            <span style={{ width: 18, height: 18, borderRadius: '50%',
              background:'radial-gradient(circle,#ff2d92,#6b1f9a)' }} />
            <span style={{ fontSize: 12.5, fontWeight: 600 }}>Daily brief</span>
            <span style={{ flex: 1 }} />
            <span style={{ fontSize: 10.5, color:'var(--text-4)' }} className="mono">9:41 AM</span>
          </div>
          <div style={{ flex: 1, overflow:'auto', padding: '12px 16px 80px', display:'flex', flexDirection:'column', gap: 12 }}>
            <Brief
              accent="var(--hot)"
              eyebrow="DECISION NEEDED"
              title="Lattice IC memo is due Friday."
              body="You haven't logged founder references yet. 3 candidates are in your network — Maya from OpenAI, Karim ex-Modal, Aditi at Anthropic."
              cta="Draft outreach" />
            <Brief
              accent="var(--amber)"
              eyebrow="SIGNAL"
              title="Cipher Stack TS landing today."
              body="Sequoia confirmed lead this morning. Our $12M pro-rata math holds at 4.0%; consider stretch to $16M for board observer."
              cta="Open term sheet" />
            <Brief
              accent="var(--blue)"
              eyebrow="NEW IN"
              title="2 inbound this week match your Q2 thesis."
              body="Northstar Health and one more (Helix Genomics) cleared your filters: $1M+ ARR, founder-led, healthcare horizontal."
              cta="Review queue" />
            <Brief
              accent="var(--green)"
              eyebrow="CLOSED"
              title="Orbital Books closed Apr 18."
              body="$1.5M check at $16M pre, 8.5% ownership. Imani sent the fund a thank-you note."
              cta="Add to portfolio" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Lens({ active, label }) {
  return (
    <div className={`orb-row ${active ? 'is-active' : ''}`} style={{ gridTemplateColumns:'14px 1fr auto', padding:'7px 10px' }}>
      <span style={{ width: 6, height: 6, borderRadius:3, background: active ? 'var(--magenta)' : 'var(--text-4)' }} />
      <span className="title" style={{ fontSize: 12, color: active ? '#fff' : 'var(--text-2)', fontWeight: active ? 600 : 400 }}>{label}</span>
      <span/>
    </div>
  );
}

function Brief({ accent, eyebrow, title, body, cta }) {
  return (
    <div style={{ background:'var(--surface-1)', border:'1px solid var(--line)',
      borderRadius: 10, padding: 12, position:'relative', overflow:'hidden' }}>
      <div style={{ position:'absolute', top: 0, left: 0, bottom: 0, width: 2, background: accent }} />
      <div style={{ fontSize: 9.5, fontWeight: 700, color: accent,
        textTransform:'uppercase', letterSpacing:'.1em' }}>{eyebrow}</div>
      <div style={{ marginTop: 4, fontSize: 12.5, fontWeight: 600, color:'#fff', lineHeight: 1.35 }}>{title}</div>
      <div style={{ marginTop: 6, fontSize: 11.5, color:'var(--text-2)', lineHeight: 1.5 }}>{body}</div>
      <div style={{ marginTop: 8, fontSize: 11, color: accent, fontWeight: 500 }}>{cta} →</div>
    </div>
  );
}

window.V4Spatial = V4Spatial;

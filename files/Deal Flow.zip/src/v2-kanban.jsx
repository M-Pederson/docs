// Variation 2 — Kanban board across pipeline stages
// Six columns, draggable-looking cards, magenta glow on the "IC" column header
// to call attention to where the action is. Footer global AI bar.

function V2Kanban() {
  // Column → deals
  const cols = STAGES.map(s => ({
    ...s,
    deals: DEALS.filter(d => d.stage === s.id),
  }));

  return (
    <div className="orb" style={{ width: 1280, height: 800, position:'relative', overflow:'hidden' }}>
      <TopNav active="dealflow" />

      <div style={{ position:'absolute', top: 44, left: 0, right: 0, bottom: 0,
                    display:'grid', gridTemplateColumns: '232px 1fr' }}>
        {/* Left rail collapsed to filters */}
        <div className="orb-rail">
          <div className="orb-rail-head">Deal Flow</div>
          <div className="orb-search">Search deals…</div>
          <div className="orb-rail-list" style={{ paddingTop: 4 }}>
            <SectionLabel>Views</SectionLabel>
            <FilterRow active label="Pipeline" icon="grid" count="49" />
            <FilterRow label="Hot deals" icon="flame" count="6" tone="hot" />
            <FilterRow label="My deals" icon="user" count="14" />
            <FilterRow label="IC this week" icon="star" count="3" tone="warn" />
            <FilterRow label="Closing soon" icon="check" count="2" tone="good" />

            <SectionLabel style={{ marginTop: 14 }}>Sectors</SectionLabel>
            <FilterRow label="AI Infra" count="11" dot="#ff2d92" />
            <FilterRow label="Dev Tools" count="6" dot="#5b8def" />
            <FilterRow label="Health" count="4" dot="#a26bff" />
            <FilterRow label="Climate" count="3" dot="#22c08a" />
            <FilterRow label="Security" count="5" dot="#f5a524" />
            <FilterRow label="Fintech" count="7" dot="#ff8a3d" />

            <SectionLabel style={{ marginTop: 14 }}>Saved</SectionLabel>
            <FilterRow label="YC W26 batch" count="9" />
            <FilterRow label="Need to revisit" count="4" />
          </div>
        </div>

        {/* Board */}
        <div style={{ position:'relative', display:'flex', flexDirection:'column', minWidth: 0 }}>

          {/* Toolbar */}
          <div style={{ display:'flex', alignItems:'center', gap: 12, padding: '14px 24px 10px',
                        borderBottom: '1px solid var(--line)' }}>
            <div style={{ display:'flex', gap: 4, padding: 3, borderRadius: 8, background:'var(--surface-1)', border:'1px solid var(--line)' }}>
              <Tab active label="Board" />
              <Tab label="Table" />
              <Tab label="Calendar" />
              <Tab label="Map" />
            </div>
            <div style={{ flex: 1 }} />
            <span className="orb-pill"><span className="dot" style={{ background:'var(--magenta)' }} />Q2 · Apr–Jun</span>
            <span className="orb-pill">Owner: All</span>
            <span className="orb-pill">⚙ Edit stages</span>
            <span className="orb-pill" style={{ color:'var(--magenta)', borderColor:'rgba(255,45,146,.3)' }}>+ Add deal</span>
          </div>

          {/* Columns */}
          <div style={{ flex: 1, display:'grid', gridTemplateColumns: 'repeat(6, minmax(0,1fr))',
                        gap: 10, padding: '12px 24px 110px', overflow:'hidden' }}>
            {cols.slice(0,6).map((col) => (
              <KanbanCol key={col.id} col={col} highlight={col.id === 'ic'} />
            ))}
          </div>

          {/* Footer global AI */}
          <div style={{ position:'absolute', left: 24, right: 24, bottom: 22 }}>
            <AskBar placeholder="Ask Orbiter about your pipeline — “Which IC deals are still missing references?”" />
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionLabel({ children, style }) {
  return <div style={{ padding: '8px 12px 4px', fontSize: 10, color:'var(--text-4)',
    textTransform:'uppercase', letterSpacing:'.08em', fontWeight: 600, ...style }}>{children}</div>;
}

function FilterRow({ active, label, count, icon, tone, dot }) {
  const toneColor = tone === 'hot' ? 'var(--hot)' : tone === 'warn' ? 'var(--amber)' : tone === 'good' ? 'var(--green)' : 'var(--text-2)';
  return (
    <div className={`orb-row ${active ? 'is-active' : ''}`}
      style={{ gridTemplateColumns: '20px 1fr auto', padding:'7px 10px', marginBottom: 1 }}>
      <div className="icon" style={{ width: 16, height: 16, background: 'transparent' }}>
        {dot
          ? <span style={{ width: 7, height: 7, borderRadius: '50%', background: dot }} />
          : <FilterIcon name={icon} color={toneColor} />}
      </div>
      <div className="title" style={{ fontSize: 12.5, fontWeight: active ? 600 : 400, color: active ? '#fff' : 'var(--text-2)' }}>{label}</div>
      <div className="count">{count}</div>
    </div>
  );
}

function FilterIcon({ name, color }) {
  const paths = {
    grid: 'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
    flame: 'M12 2c1 4 5 5 5 10a5 5 0 0 1-10 0c0-3 2-4 2-7M9 13a3 3 0 0 0 6 0',
    user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
    star: 'M12 3l2.6 6 6.4.6-4.8 4.4 1.4 6.4L12 17.3 6.4 20.4l1.4-6.4L3 9.6l6.4-.6z',
    check: 'M5 12l5 5L20 7',
  };
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={color || 'currentColor'} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d={paths[name] || paths.grid} />
    </svg>
  );
}

function Tab({ active, label }) {
  return (
    <div style={{
      padding: '5px 12px', borderRadius: 6, fontSize: 12,
      fontWeight: active ? 600 : 400,
      color: active ? '#fff' : 'var(--text-3)',
      background: active ? 'var(--surface-3)' : 'transparent',
    }}>{label}</div>
  );
}

function KanbanCol({ col, highlight }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', minWidth: 0, height:'100%' }}>
      <div style={{ display:'flex', alignItems:'center', gap: 8, padding: '4px 6px 10px' }}>
        <span style={{ width: 6, height: 6, borderRadius: 3, background: col.color,
          boxShadow: highlight ? `0 0 8px ${col.color}` : 'none' }} />
        <span style={{ fontSize: 11.5, fontWeight: 600, color: highlight ? '#fff' : 'var(--text-2)',
          textTransform:'uppercase', letterSpacing:'.06em' }}>{col.label}</span>
        <span style={{ fontSize: 11, color:'var(--text-4)' }} className="mono">{col.deals.length}</span>
        <span style={{ flex: 1 }} />
        <span style={{ color:'var(--text-4)', fontSize: 14, lineHeight: 1 }}>+</span>
      </div>
      <div style={{ flex: 1, display:'flex', flexDirection:'column', gap: 8, overflow:'hidden',
                    background: highlight ? 'radial-gradient(120% 60% at 50% 0%, rgba(255,45,146,.10), transparent 60%)' : 'transparent',
                    borderRadius: 10, padding: highlight ? '4px 4px 0' : 0 }}>
        {col.deals.map(d => <KanbanCard key={d.id} d={d} hot={highlight && d.temp==='hot'} />)}
        {col.deals.length === 0 && (
          <div style={{ border: '1px dashed var(--line)', borderRadius: 8, height: 64,
            display:'flex', alignItems:'center', justifyContent:'center',
            color:'var(--text-4)', fontSize: 11 }}>Drop here</div>
        )}
      </div>
    </div>
  );
}

function KanbanCard({ d, hot }) {
  return (
    <div style={{
      background: hot
        ? 'linear-gradient(180deg, rgba(255,45,146,.10), rgba(20,8,32,.0)), var(--surface-1)'
        : 'var(--surface-1)',
      border: '1px solid', borderColor: hot ? 'rgba(255,45,146,.22)' : 'var(--line)',
      borderRadius: 9, padding: 10,
      boxShadow: hot ? '0 0 0 0 rgba(255,45,146,.0), 0 12px 28px -8px rgba(255,45,146,.18)' : 'none',
    }}>
      <div style={{ display:'flex', gap: 8, alignItems:'flex-start' }}>
        <CompanyTile deal={d} size={26} radius={6} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, lineHeight: 1.2,
            whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{d.name}</div>
          <div style={{ fontSize: 10.5, color:'var(--text-3)', marginTop: 2 }}>{d.sector}</div>
        </div>
        {hot && <span style={{ width: 6, height: 6, borderRadius: 3, background:'var(--hot)',
          boxShadow:'0 0 6px var(--hot)' }} />}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 4, marginTop: 10 }}>
        <Mini label="Round" value={d.round} />
        <Mini label="Raising" value={d.raising} />
      </div>
      {d.check !== '—' && (
        <div style={{ marginTop: 8, padding: '6px 8px', background:'rgba(255,255,255,.03)',
          borderRadius: 6, display:'flex', justifyContent:'space-between', fontSize: 10.5 }}>
          <span style={{ color:'var(--text-3)' }}>Our check</span>
          <span className="mono" style={{ fontWeight: 600, color:'#fff' }}>{d.check}</span>
        </div>
      )}
      <div style={{ marginTop: 8, display:'flex', alignItems:'center', gap: 6 }}>
        <Avatars n={d.team > 8 ? 3 : 2} />
        <span style={{ flex: 1 }} />
        <span style={{ fontSize: 10, color:'var(--text-4)' }}>{d.nextDate}</span>
      </div>
    </div>
  );
}

function Mini({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 9.5, color:'var(--text-4)', textTransform:'uppercase', letterSpacing: '.06em' }}>{label}</div>
      <div className="mono" style={{ fontSize: 11.5, color:'var(--text-2)', marginTop: 1 }}>{value}</div>
    </div>
  );
}

function Avatars({ n }) {
  const colors = ['#ff2d92','#5b8def','#22c08a','#a26bff'];
  return (
    <div style={{ display:'flex' }}>
      {Array.from({ length: n }).map((_, i) => (
        <div key={i} style={{ width: 18, height: 18, borderRadius: '50%',
          background: colors[i % colors.length],
          marginLeft: i ? -6 : 0, border: '2px solid var(--surface-1)',
          fontSize: 8.5, fontWeight: 700, color:'#fff',
          display:'inline-flex', alignItems:'center', justifyContent:'center' }}>
          {['M','J','S','T'][i]}
        </div>
      ))}
    </div>
  );
}

window.V2Kanban = V2Kanban;

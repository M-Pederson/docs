// Variation 3 — Dense table / spreadsheet view
// Power-user mode: every deal as a row with check size, ownership, ARR,
// next step. Sticky stage rollup at top. Footer global AI bar.

function V3Table() {
  const stageOrder = ['ic','termsheet','diligence','firstcall','sourced','closed','passed'];
  const grouped = stageOrder.map(sid => ({
    stage: STAGES.find(s => s.id === sid),
    deals: DEALS.filter(d => d.stage === sid),
  })).filter(g => g.deals.length);

  return (
    <div className="orb" style={{ width: 1280, height: 800, position:'relative', overflow:'hidden' }}>
      <TopNav active="dealflow" />

      <div style={{ position:'absolute', top: 44, left: 0, right: 0, bottom: 0,
                    display:'grid', gridTemplateColumns: '232px 1fr' }}>
        <div className="orb-rail">
          <div className="orb-rail-head">Deal Flow</div>
          <div className="orb-search">Search deals…</div>
          <div className="orb-rail-list" style={{ paddingTop: 4 }}>
            <SectionLabel>Views</SectionLabel>
            <FilterRow label="Pipeline" icon="grid" count="49" />
            <FilterRow active label="All deals (table)" icon="grid" count="49" />
            <FilterRow label="My deals" icon="user" count="14" />
            <FilterRow label="Closing soon" icon="check" count="2" tone="good" />
            <SectionLabel style={{ marginTop: 14 }}>Pipeline ($ raising)</SectionLabel>
            {STAGES.slice(0,6).map(s => (
              <div key={s.id} className="orb-row" style={{ gridTemplateColumns:'12px 1fr auto', padding:'7px 10px' }}>
                <span style={{ width: 6, height: 6, borderRadius: 3, background: s.color }} />
                <div className="title" style={{ fontSize: 12, color:'var(--text-2)' }}>{s.label}</div>
                <div className="count">{s.count}</div>
              </div>
            ))}
            <div style={{ margin: '14px 12px', padding: 10, background:'var(--surface-1)',
                          border:'1px solid var(--line)', borderRadius: 8 }}>
              <div style={{ fontSize: 10, color:'var(--text-4)', textTransform:'uppercase', letterSpacing:'.06em' }}>Total raising</div>
              <div className="mono" style={{ fontSize: 18, fontWeight: 600, marginTop: 2 }}>$94.0M</div>
              <div style={{ fontSize: 10.5, color:'var(--text-3)', marginTop: 2 }}>Across 8 active deals</div>
            </div>
          </div>
        </div>

        {/* Table area */}
        <div style={{ display:'flex', flexDirection:'column', minWidth: 0 }}>
          {/* Stage rollup ribbon */}
          <div style={{ padding:'14px 24px 12px', borderBottom:'1px solid var(--line)' }}>
            <div style={{ display:'flex', alignItems:'center', gap: 12 }}>
              <div style={{ display:'flex', gap: 4, padding: 3, borderRadius: 8, background:'var(--surface-1)', border:'1px solid var(--line)' }}>
                <Tab label="Board" />
                <Tab active label="Table" />
                <Tab label="Calendar" />
                <Tab label="Map" />
              </div>
              <div style={{ flex: 1 }} />
              <span className="orb-pill">⊟ Group: Stage</span>
              <span className="orb-pill">⇅ Sort: Next step</span>
              <span className="orb-pill">⊕ 12 columns</span>
            </div>
            <div style={{ display:'flex', gap: 8, marginTop: 12 }}>
              {STAGES.slice(0,6).map(s => (
                <div key={s.id} style={{ flex: 1, padding: '8px 10px',
                  background:'var(--surface-1)', border:'1px solid var(--line)', borderRadius: 8,
                  position:'relative', overflow:'hidden' }}>
                  <div style={{ position:'absolute', top:0, left:0, right:0, height: 2, background: s.color, opacity:.7 }} />
                  <div style={{ fontSize: 10, color:'var(--text-3)', textTransform:'uppercase', letterSpacing:'.06em' }}>{s.label}</div>
                  <div style={{ display:'flex', alignItems:'baseline', gap: 6, marginTop: 4 }}>
                    <span className="mono" style={{ fontSize: 16, fontWeight: 600 }}>{s.count}</span>
                    <span style={{ fontSize: 10.5, color:'var(--text-4)' }} className="mono">deals</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Table */}
          <div style={{ flex: 1, overflow:'hidden' }}>
            <div style={{ display:'grid',
              gridTemplateColumns: '24px 200px 90px 90px 90px 80px 80px 80px 1fr 90px',
              padding:'8px 24px', fontSize: 10.5, color:'var(--text-3)',
              textTransform:'uppercase', letterSpacing:'.06em', fontWeight: 600,
              borderBottom:'1px solid var(--line)' }}>
              <span></span>
              <span>Company</span>
              <span>Sector</span>
              <span>Round</span>
              <span>Raising</span>
              <span>Check</span>
              <span>Own %</span>
              <span>ARR</span>
              <span>Next step</span>
              <span style={{ textAlign:'right' }}>Owner</span>
            </div>
            <div style={{ overflow:'auto', height:'calc(100% - 32px)', paddingBottom: 80 }}>
              {grouped.map(g => (
                <div key={g.stage.id}>
                  {/* Stage header row */}
                  <div style={{ display:'flex', alignItems:'center', gap: 8,
                    padding:'10px 24px 6px', background:'rgba(255,255,255,.015)' }}>
                    <span style={{ width: 6, height: 6, borderRadius: 3, background: g.stage.color }} />
                    <span style={{ fontSize: 10.5, fontWeight: 600,
                      textTransform:'uppercase', letterSpacing:'.08em',
                      color: g.stage.id === 'ic' ? '#fff' : 'var(--text-2)' }}>{g.stage.label}</span>
                    <span className="mono" style={{ fontSize: 10.5, color:'var(--text-4)' }}>· {g.deals.length}</span>
                    <span style={{ flex: 1, height: 1, background:'var(--line)', marginLeft: 6 }} />
                  </div>
                  {g.deals.map((d, i) => <TableRow key={d.id} d={d} hot={d.temp === 'hot' && g.stage.id === 'ic'} />)}
                </div>
              ))}
            </div>
          </div>

          {/* Footer ask */}
          <div style={{ position:'absolute', left: 256, right: 24, bottom: 22 }}>
            <AskBar placeholder="Ask Orbiter — “Sum the check size across IC + Term sheet”" />
          </div>
        </div>
      </div>
    </div>
  );
}

function TableRow({ d, hot }) {
  return (
    <div style={{
      display:'grid',
      gridTemplateColumns: '24px 200px 90px 90px 90px 80px 80px 80px 1fr 90px',
      padding:'10px 24px', fontSize: 12, alignItems:'center',
      borderBottom:'1px solid var(--line)',
      background: hot ? 'linear-gradient(90deg, rgba(255,45,146,.06), transparent 30%)' : 'transparent',
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 3,
        background: hot ? 'var(--hot)' : 'transparent',
        boxShadow: hot ? '0 0 6px var(--hot)' : 'none' }} />
      <div style={{ display:'flex', gap: 8, alignItems:'center', minWidth: 0 }}>
        <CompanyTile deal={d} size={22} radius={5} />
        <div style={{ minWidth: 0 }}>
          <div style={{ fontWeight: 600, color:'#fff', fontSize: 12.5,
            whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{d.name}</div>
          <div style={{ fontSize: 10.5, color:'var(--text-4)' }}>{d.domain}</div>
        </div>
      </div>
      <span style={{ color:'var(--text-2)' }}>{d.sector}</span>
      <span style={{ color:'var(--text-2)' }}>{d.round}</span>
      <span className="mono" style={{ color:'#fff', fontWeight: 500 }}>{d.raising}</span>
      <span className="mono" style={{ color: d.check === '—' ? 'var(--text-4)' : '#fff' }}>{d.check}</span>
      <span className="mono" style={{ color: d.ownership === '—' ? 'var(--text-4)' : 'var(--text-2)' }}>{d.ownership}</span>
      <span className="mono" style={{ color: d.arr.includes('Pre') ? 'var(--text-4)' : 'var(--text-2)' }}>{d.arr}</span>
      <div style={{ display:'flex', alignItems:'center', gap: 8, color:'var(--text-2)' }}>
        <span style={{ flex: 1, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{d.nextStep}</span>
        <span className="mono" style={{ fontSize: 10.5, color:'var(--text-3)' }}>{d.nextDate}</span>
      </div>
      <div style={{ display:'flex', justifyContent:'flex-end' }}>
        <Avatars n={2} />
      </div>
    </div>
  );
}

window.V3Table = V3Table;

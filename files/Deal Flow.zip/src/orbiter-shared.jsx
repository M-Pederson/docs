// Shared Orbiter chrome — top nav, left rail, deal data
// Globals exposed: TopNav, LeftRail, AskBar, DEALS, STAGES, PEOPLE,
//   CompanyTile, StagePill, MoneyRow

const STAGES = [
  { id: 'sourced',   label: 'Sourced',     count: 14, color: '#76767c' },
  { id: 'firstcall', label: 'First call',  count: 9,  color: '#5b8def' },
  { id: 'diligence', label: 'Diligence',   count: 6,  color: '#f5a524' },
  { id: 'ic',        label: 'IC',          count: 3,  color: '#ff3d8a' },
  { id: 'termsheet', label: 'Term sheet',  count: 2,  color: '#a26bff' },
  { id: 'closed',    label: 'Closed',      count: 4,  color: '#22c08a' },
  { id: 'passed',    label: 'Passed',      count: 11, color: '#4a4a50' },
];

// Realistic-sounding (fictional) deals
const DEALS = [
  {
    id: 'lattice',
    name: 'Lattice Compute',
    domain: 'lattice.computer',
    mark: 'L',
    markBg: 'linear-gradient(135deg,#ff2d92,#6b1f9a)',
    sector: 'AI Infra',
    hq: 'San Francisco',
    stage: 'ic',
    temp: 'hot',
    round: 'Series A',
    raising: '$22M',
    pre: '$110M pre',
    check: '$8M',
    ownership: '6.7%',
    leadStatus: 'Leading',
    intro: 'Warm intro · S. Ravi (a16z)',
    nextStep: 'IC memo due Fri',
    nextDate: 'Apr 30',
    arr: '$3.4M',
    growth: '+38% MoM',
    burn: '$420k/mo',
    runway: '18 mo',
    team: 14,
    founders: ['Maya Iyer', 'Jonas Park'],
    tagline: 'Distributed inference runtime that schedules LLM jobs across heterogeneous GPU fleets — bursty workloads at 1/3 the cost of dedicated H100 clusters.',
    summary: '<em>Lattice Compute</em> is a Series A AI-infra company building a distributed inference runtime that lets enterprise teams run LLM workloads across mixed GPU fleets, claiming 3× cost efficiency vs. dedicated clusters at p95 latencies under 80ms.',
    signals: [
      { label: 'Founder ex-Anthropic', tone: 'good' },
      { label: 'a16z lead committed', tone: 'good' },
      { label: 'Crowded space', tone: 'warn' },
      { label: 'Single design partner', tone: 'warn' },
    ],
  },
  {
    id: 'verdant',
    name: 'Verdant Labs',
    domain: 'verdant.bio',
    mark: 'V',
    markBg: 'linear-gradient(135deg,#22c08a,#0a6b4a)',
    sector: 'Climate / Bio',
    hq: 'Boston',
    stage: 'diligence',
    temp: 'warm',
    round: 'Seed+',
    raising: '$9M',
    pre: '$36M pre',
    check: '$3M',
    ownership: '7.5%',
    leadStatus: 'Co-lead',
    intro: 'Outbound · LinkedIn',
    nextStep: 'Lab visit',
    nextDate: 'May 6',
    arr: 'Pre-revenue',
    growth: '3 LOIs',
    burn: '$180k/mo',
    runway: '14 mo',
    team: 8,
    founders: ['Dr. Aiyana Reed', 'Ben Okafor'],
    tagline: 'Soil-microbiome sequencing kits that predict crop yield 6 months out — sold to mid-size ag co-ops on a per-acre subscription.',
    summary: '<em>Verdant Labs</em> sequences soil microbiomes to predict crop yield with 89% accuracy six months out, sold per-acre to mid-size co-ops. Three signed LOIs, FDA-adjacent regulatory path is the open question.',
    signals: [
      { label: 'Defensible IP (3 patents)', tone: 'good' },
      { label: 'Long sales cycle', tone: 'warn' },
      { label: 'Capex-heavy', tone: 'warn' },
    ],
  },
  {
    id: 'parallel',
    name: 'Parallel',
    domain: 'parallel.dev',
    mark: 'P',
    markBg: 'linear-gradient(135deg,#5b8def,#1f3a8f)',
    sector: 'Dev Tools',
    hq: 'Remote',
    stage: 'firstcall',
    temp: 'hot',
    round: 'Seed',
    raising: '$5M',
    pre: '$20M pre',
    check: '$2M',
    ownership: '8.0%',
    leadStatus: 'Solo lead',
    intro: 'YC W26 demo day',
    nextStep: 'Founder dinner',
    nextDate: 'May 1',
    arr: '$640k',
    growth: '+22% MoM',
    burn: '$95k/mo',
    runway: '11 mo',
    team: 5,
    founders: ['Sana Qureshi', 'Theo Lin'],
    tagline: 'Parallel test runner for monorepos. Cuts CI from 18 min to 90 sec by sharding intelligently across changed files.',
    summary: '<em>Parallel</em> is a YC W26 dev-tools company that shards test suites by changed-file graph, taking enterprise CI from 18min to ~90s. Eight design partners, $640k ARR after four months.',
    signals: [
      { label: 'YC top batch', tone: 'good' },
      { label: 'Strong ARR for stage', tone: 'good' },
      { label: 'Competitive: Buildkite, Trunk', tone: 'warn' },
    ],
  },
  {
    id: 'northstar',
    name: 'Northstar Health',
    domain: 'northstar.care',
    mark: 'N',
    markBg: 'linear-gradient(135deg,#a26bff,#3a1a6b)',
    sector: 'Health',
    hq: 'New York',
    stage: 'sourced',
    temp: 'cool',
    round: 'Series A',
    raising: '$18M',
    pre: '$80M pre',
    check: '—',
    ownership: '—',
    leadStatus: 'Watching',
    intro: 'Inbound · founder email',
    nextStep: 'Decide if call',
    nextDate: 'May 8',
    arr: '$1.1M',
    growth: '+12% MoM',
    burn: '$210k/mo',
    runway: '20 mo',
    team: 11,
    founders: ['Dr. Priya Shah'],
    tagline: 'Specialty-care navigation for self-insured employers. Routes employees to high-quality, in-network specialists.',
    summary: '<em>Northstar Health</em> routes self-insured employees to high-quality specialists, claiming 14% reduction in claim costs. Solo founder, ex-Oscar. Sourced inbound — early in evaluation.',
    signals: [
      { label: 'Strong unit economics', tone: 'good' },
      { label: 'Solo founder', tone: 'warn' },
      { label: 'Crowded category', tone: 'warn' },
    ],
  },
  {
    id: 'cipher',
    name: 'Cipher Stack',
    domain: 'cipherstack.io',
    mark: 'C',
    markBg: 'linear-gradient(135deg,#f5a524,#8a4a00)',
    sector: 'Security',
    hq: 'Tel Aviv',
    stage: 'termsheet',
    temp: 'hot',
    round: 'Series B',
    raising: '$45M',
    pre: '$280M pre',
    check: '$12M',
    ownership: '4.0%',
    leadStatus: 'Following',
    intro: 'Co-investor (Sequoia)',
    nextStep: 'Sign TS',
    nextDate: 'Apr 29',
    arr: '$11.2M',
    growth: '+9% MoM',
    burn: '$680k/mo',
    runway: '24 mo',
    team: 38,
    founders: ['Idan Cohen', 'Maya Levin'],
    tagline: 'Runtime supply-chain security for Kubernetes. Detects compromised dependencies in production within 90 seconds.',
    summary: '<em>Cipher Stack</em> detects compromised dependencies in K8s clusters in <90s. $11.2M ARR, 4× YoY. Sequoia leading, term sheet in flight.',
    signals: [
      { label: 'Sequoia leading', tone: 'good' },
      { label: 'Strong retention (NRR 138%)', tone: 'good' },
      { label: 'Late stage — pricing risk', tone: 'warn' },
    ],
  },
  {
    id: 'qubit',
    name: 'Qubit Robotics',
    domain: 'qubit.bot',
    mark: 'Q',
    markBg: 'linear-gradient(135deg,#ef4444,#7a0a0a)',
    sector: 'Robotics',
    hq: 'Pittsburgh',
    stage: 'sourced',
    temp: 'warm',
    round: 'Seed',
    raising: '$7M',
    pre: '$25M pre',
    check: '—',
    ownership: '—',
    leadStatus: 'Watching',
    intro: 'CMU referral',
    nextStep: 'Tech DD call',
    nextDate: 'May 12',
    arr: 'Pre-revenue',
    growth: '2 pilots',
    burn: '$140k/mo',
    runway: '9 mo',
    team: 6,
    founders: ['Wei Chen', 'Jordan Ames'],
    tagline: 'Bin-picking foundation model for warehouse automation. Plug into existing arms, no per-SKU training.',
    summary: '<em>Qubit Robotics</em> built a bin-picking foundation model that drops into existing robot arms with no per-SKU training. Two paid pilots with 3PL operators.',
    signals: [
      { label: 'CMU founders', tone: 'good' },
      { label: 'Hardware capex', tone: 'warn' },
      { label: '9mo runway', tone: 'warn' },
    ],
  },
  {
    id: 'orbital',
    name: 'Orbital Books',
    domain: 'orbital.so',
    mark: 'O',
    markBg: 'linear-gradient(135deg,#ff8a3d,#7a3500)',
    sector: 'Fintech',
    hq: 'London',
    stage: 'closed',
    temp: 'good',
    round: 'Seed',
    raising: '$4M',
    pre: '$16M pre',
    check: '$1.5M',
    ownership: '8.5%',
    leadStatus: 'Led',
    intro: 'Portfolio referral',
    nextStep: 'Board kickoff',
    nextDate: 'May 14',
    arr: '$310k',
    growth: '+45% MoM',
    burn: '$70k/mo',
    runway: '36 mo',
    team: 4,
    founders: ['Imani Clarke'],
    tagline: 'Real-time bookkeeping for SMB e-commerce. Books always up to date, no monthly close.',
    summary: '<em>Orbital Books</em> automates bookkeeping for SMB e-commerce via real-time bank+platform sync. Closed Apr 18 — we led.',
    signals: [
      { label: 'Closed (we led)', tone: 'good' },
      { label: '+45% MoM growth', tone: 'good' },
    ],
  },
  {
    id: 'meridian',
    name: 'Meridian',
    domain: 'meridian.fm',
    mark: 'M',
    markBg: 'linear-gradient(135deg,#22c08a,#1a3a5a)',
    sector: 'Consumer',
    hq: 'Brooklyn',
    stage: 'passed',
    temp: 'cold',
    round: 'Seed',
    raising: '$3M',
    pre: '$15M pre',
    check: '—',
    ownership: '—',
    leadStatus: 'Passed',
    intro: 'Cold inbound',
    nextStep: 'Send pass note',
    nextDate: '—',
    arr: '$80k',
    growth: '—',
    burn: '$60k/mo',
    runway: '8 mo',
    team: 3,
    founders: ['Asha Vance'],
    tagline: 'Social audio for hobbyist communities.',
    summary: 'Passed — TAM concerns, social audio category headwinds.',
    signals: [{ label: 'Passed Apr 22', tone: 'cold' }],
  },
];

// Key people related to deals
const PEOPLE = [
  { name: 'Maya Iyer',     role: 'CEO, Lattice Compute',   tag: 'Founder',  hot: true,  initials: 'MI', color: '#ff2d92' },
  { name: 'Sana Qureshi',  role: 'CEO, Parallel',          tag: 'Founder',  hot: true,  initials: 'SQ', color: '#5b8def' },
  { name: 'S. Ravi',       role: 'GP, a16z',               tag: 'Co-lead',  hot: false, initials: 'SR', color: '#a26bff' },
  { name: 'Idan Cohen',    role: 'CEO, Cipher Stack',      tag: 'Founder',  hot: true,  initials: 'IC', color: '#f5a524' },
  { name: 'Dr. Aiyana Reed', role: 'CEO, Verdant Labs',    tag: 'Founder',  hot: false, initials: 'AR', color: '#22c08a' },
  { name: 'Imani Clarke',  role: 'CEO, Orbital Books',     tag: 'Portfolio', hot: false, initials: 'IC', color: '#ff8a3d' },
];

// ─── Top icon nav (mirrors screenshot) ────────────────────────────
function TopNav({ active = 'dealflow' }) {
  const icons = [
    { id: 'inbox',     label: 'Inbox',     badge: '8+',
      d: 'M3 7l9 6 9-6M3 7v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7M3 7l2-2h14l2 2' },
    { id: 'people',    label: 'People',    badge: '6+',
      d: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM3 21a6 6 0 0 1 12 0M16 11a3 3 0 1 0 0-6M21 21a5 5 0 0 0-5-5' },
    { id: 'dealflow',  label: 'Deal flow', badge: '',
      d: 'M3 12l4-8 5 14 4-9 5 6' },
    { id: 'calendar',  label: 'Calendar',  badge: '2',
      d: 'M4 6h16v14H4zM4 6V4h16v2M8 2v4M16 2v4M4 10h16' },
    { id: 'tasks',     label: 'Tasks',     badge: '',
      d: 'M5 6h2M5 12h2M5 18h2M10 6h10M10 12h10M10 18h10' },
    { id: 'crm',       label: 'CRM',       badge: '1',
      d: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z' },
  ];
  return (
    <div className="orb-topnav">
      <div className="left">
        <div className="orb-iconbtn" title="History">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" />
          </svg>
        </div>
      </div>
      <div className="center">
        {icons.map((it) => (
          <div key={it.id} className="orb-iconbtn"
               style={{ color: it.id === active ? '#fff' : 'var(--text-3)' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d={it.d} />
            </svg>
            {it.badge && <span className="badge">{it.badge}</span>}
            {it.id === active && (
              <div style={{ position:'absolute', bottom:-10, left:'50%', transform:'translateX(-50%)',
                width: 18, height: 2, background: 'var(--magenta)', borderRadius: 2,
                boxShadow: '0 0 8px var(--magenta)' }} />
            )}
          </div>
        ))}
      </div>
      <div className="right" style={{ justifyContent:'flex-end' }}>
        <div className="orb-iconbtn">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M9 11l3 3L22 4M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
          </svg>
          <span className="badge">4+</span>
        </div>
        <div className="orb-iconbtn">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0" />
          </svg>
          <span className="badge">2</span>
        </div>
        <div className="orb-globe" />
      </div>
    </div>
  );
}

// ─── Company tile (square gradient mark) ──────────────────────────
function CompanyTile({ deal, size = 36, radius = 8 }) {
  return (
    <div className="orb-tile"
      style={{
        width: size, height: size, borderRadius: radius,
        background: deal.markBg,
        fontSize: size * 0.4,
        boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.08)',
      }}>{deal.mark}</div>
  );
}

function StagePill({ stage, hot }) {
  const s = STAGES.find(x => x.id === stage);
  if (!s) return null;
  return (
    <span className="orb-pill"
      style={{ borderColor: `${s.color}3d`, background: `${s.color}14`, color: s.color }}>
      <span className="dot" style={{ background: s.color, boxShadow: hot ? `0 0 6px ${s.color}` : 'none' }} />
      {s.label}
    </span>
  );
}

// ─── Ask bar (footer) ─────────────────────────────────────────────
function AskBar({ placeholder = 'Ask anything about your pipeline…' }) {
  return (
    <div className="orb-ask">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--magenta)' }}>
        <path d="M12 2l2.4 6.4L21 11l-6.6 2.6L12 20l-2.4-6.4L3 11l6.6-2.6z" />
      </svg>
      <span style={{ flex: 1 }}>{placeholder}</span>
      <span style={{ display:'inline-flex', alignItems:'center', gap:8, fontSize: 11, color:'var(--text-4)' }}>
        <span>Pipeline ·  $94M raising · 8 active</span>
      </span>
      <div className="send">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M9 6l6 6-6 6" />
        </svg>
      </div>
    </div>
  );
}

Object.assign(window, { TopNav, CompanyTile, StagePill, AskBar, STAGES, DEALS, PEOPLE });

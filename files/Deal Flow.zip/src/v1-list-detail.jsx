// Variation 1 — Discoveries-style list + single deal hero (closest to current Orbiter pattern)
// Left rail = list of deals; main canvas = magenta-glow hero on the active deal,
// followed by inline source/research cards. Footer ask bar. 1280×800.

function V1ListDetail() {
  const active = DEALS[0]; // Lattice Compute
  const sub = DEALS.filter(d => d.id !== 'meridian');

  return (
    <div className="orb" style={{ width: 1280, height: 800, position: 'relative', overflow:'hidden' }}>
      <TopNav active="dealflow" />

      {/* Body */}
      <div style={{ position:'absolute', top: 44, left: 0, right: 0, bottom: 0,
                    display: 'grid', gridTemplateColumns: '232px 1fr' }}>

        {/* Left rail — exactly like Discover */}
        <div className="orb-rail">
          <div className="orb-rail-head">Deal Flow</div>
          <div className="orb-search">Search deals…</div>
          <div className="orb-rail-list">
            {sub.map((d) => (
              <div key={d.id} className={`orb-row ${d.id === active.id ? 'is-active' : ''}`}>
                <div className="icon">
                  {d.id === active.id ? (
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M3 12l4-8 5 14 4-9 5 6"/></svg>
                  ) : (
                    <span style={{
                      width: 14, height: 14, borderRadius: 4,
                      background: d.markBg, fontSize: 8, fontWeight: 800,
                      display:'inline-flex', alignItems:'center', justifyContent:'center',
                      color:'#fff'
                    }}>{d.mark}</span>
                  )}
                </div>
                <div>
                  <div className="title">{d.name}</div>
                  <div className="meta">{d.round} · {d.raising}</div>
                </div>
                <div className="count">
                  {d.temp === 'hot'
                    ? <span style={{color:'var(--hot)'}}>●</span>
                    : <span>{STAGES.find(s=>s.id===d.stage)?.label.slice(0,3)}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Main canvas */}
        <div style={{ position:'relative', padding: '24px 56px 0' }}>
          {/* Hero glow card */}
          <div className="orb-hero">
            <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap: 16 }}>
              <div className="orb-eyebrow">DEAL FLOW · IC THIS WEEK</div>
              <div style={{ display:'flex', gap: 8, alignItems:'center', position:'relative', zIndex:2 }}>
                <StagePill stage={active.stage} hot />
                <span className="orb-pill hot"><span className="dot"/>Hot</span>
                <button style={{ width: 26, height: 26, borderRadius: 6, background: 'rgba(255,255,255,.08)',
                  border: '1px solid rgba(255,255,255,.10)', color: '#fff', display:'inline-flex', alignItems:'center', justifyContent:'center' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
                </button>
              </div>
            </div>
            <p className="orb-headline" dangerouslySetInnerHTML={{ __html: active.summary }} />
          </div>

          {/* Two columns of source cards */}
          <div style={{ display:'grid', gridTemplateColumns:'1.05fr 1fr', gap: 14, marginTop: 14 }}>
            {/* Company card */}
            <div className="orb-card" style={{ padding: 14 }}>
              <div style={{ display:'flex', gap: 12, alignItems:'flex-start' }}>
                <CompanyTile deal={active} size={40} radius={9} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{active.name}</div>
                  <div style={{ fontSize: 11, color:'var(--text-3)' }}>{active.domain} · {active.sector} · {active.hq}</div>
                </div>
                <span className="orb-pill cool">Series A</span>
              </div>
              <div style={{ marginTop: 12, fontSize: 12, lineHeight: 1.55, color:'var(--text-2)' }}>
                {active.tagline}
              </div>
              <div style={{ marginTop: 12, display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap: 10 }}>
                {[
                  ['ARR', active.arr],
                  ['Growth', active.growth],
                  ['Burn', active.burn],
                  ['Runway', active.runway],
                ].map(([k,v]) => (
                  <div key={k} style={{ background:'var(--surface-2)', borderRadius: 7, padding:'8px 10px' }}>
                    <div style={{ fontSize: 10, color:'var(--text-3)', textTransform:'uppercase', letterSpacing: '.06em' }}>{k}</div>
                    <div className="mono" style={{ fontSize: 13, marginTop: 2, fontWeight: 500 }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Round / position card */}
            <div className="orb-card" style={{ padding: 14 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <div style={{ fontSize: 12, fontWeight: 600 }}>Round & position</div>
                <span className="orb-pill good"><span className="dot"/>{active.leadStatus}</span>
              </div>
              <div style={{ marginTop: 12, display:'grid', gridTemplateColumns:'1fr 1fr', gap: 10 }}>
                {[
                  ['Raising', active.raising],
                  ['Pre-money', active.pre.replace(' pre','')],
                  ['Our check', active.check],
                  ['Ownership', active.ownership],
                ].map(([k,v]) => (
                  <div key={k} style={{ display:'flex', justifyContent:'space-between',
                       padding:'8px 0', borderBottom:'1px dashed var(--line)', fontSize: 12 }}>
                    <span style={{ color:'var(--text-3)' }}>{k}</span>
                    <span className="mono" style={{ color:'#fff', fontWeight: 500 }}>{v}</span>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 12, fontSize: 11, color:'var(--text-3)' }}>
                Source: <span style={{ color:'var(--text-2)' }}>{active.intro}</span>
              </div>
            </div>
          </div>

          {/* Signals row */}
          <div style={{ display:'flex', gap: 8, flexWrap:'wrap', marginTop: 14 }}>
            {active.signals.map((s, i) => (
              <span key={i} className={`orb-pill ${s.tone === 'good' ? 'good' : 'warm'}`}>
                <span className="dot" />{s.label}
              </span>
            ))}
            <span style={{ flex: 1 }} />
            <span className="orb-pill" style={{ color:'var(--text-2)' }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
              Next: {active.nextStep} · {active.nextDate}
            </span>
          </div>

          {/* Footer ask bar */}
          <div style={{ position:'absolute', left: 56, right: 56, bottom: 26 }}>
            <AskBar placeholder="Ask a follow-up about Lattice Compute…" />
            <div style={{ display:'flex', justifyContent:'flex-end', gap: 12, marginTop: 8, color:'var(--text-4)', fontSize: 11 }}>
              <span>⊞</span><span>🎙</span><span>▾</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.V1ListDetail = V1ListDetail;

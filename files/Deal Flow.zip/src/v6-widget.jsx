// Deal Flow widget — matches the calendar-widget pattern shown in the screenshot.
// Centered floating panel, eyebrow + Today ▾ + Edit, item rows with date/time-style pills,
// right-side Summary | Context | Modify tabs, left "Outcomes"-style rail.

function DealFlowWidget() {
  // Match the calendar's data shape: each "deal" = one item card
  const items = [
    {
      id: 'cipher',
      name: 'Cipher Stack',
      sector: 'Security · Series B',
      datePill: '29 Apr',  dateTone: 'magenta',
      pill2: 'Sign TS',    pill2Tone: 'cyan',
      meta: '⚑ Sequoia leading · $12M check · 4.0%',
      status: 'Term sheet',
      statusTone: 'cyan',
      done: false,
      next: 'Counsel review',
    },
    {
      id: 'lattice',
      name: 'Lattice Compute',
      sector: 'AI Infra · Series A',
      datePill: '30 Apr',  dateTone: 'magenta',
      pill2: '11:00 AM',   pill2Tone: 'cyan',
      meta: '🧠 IC memo due · Maya I. + Jonas P.',
      status: 'IC',
      statusTone: 'magenta',
      done: false,
      next: 'Finish memo',
    },
    {
      id: 'parallel',
      name: 'Parallel · Founder dinner',
      sector: 'Dev Tools · Seed',
      datePill: '01 May',  dateTone: 'magenta',
      pill2: '7:30 PM',    pill2Tone: 'cyan',
      meta: '📍 Tartine · with Sana Q. + Theo L.',
      status: '« 1st call',
      statusTone: 'cyan',
      done: true,
      next: 'Decide if invest',
    },
    {
      id: 'verdant',
      name: 'Verdant Labs',
      sector: 'Climate · Seed+',
      datePill: '06 May',  dateTone: 'magenta',
      pill2: 'Lab visit',  pill2Tone: 'cyan',
      meta: '🧬 Boston · Aiyana R. + Ben O.',
      status: 'Diligence',
      statusTone: 'amber',
      done: false,
      next: 'Tech DD scoping',
    },
    {
      id: 'qubit',
      name: 'Qubit Robotics',
      sector: 'Robotics · Seed',
      datePill: '12 May',  dateTone: 'magenta',
      pill2: 'Tech DD',    pill2Tone: 'cyan',
      meta: '🤖 Pittsburgh · CMU referral',
      status: '« Sourced',
      statusTone: 'cyan',
      done: false,
      next: 'Schedule call',
    },
  ];

  return (
    <div className="orb" style={{ width: 1280, height: 800, position:'relative', overflow:'hidden' }}>
      <TopNav active="dealflow" />

      <div style={{ position:'absolute', top: 44, left: 0, right: 0, bottom: 0,
                    display:'grid', gridTemplateColumns: '232px 1fr 280px' }}>

        {/* Left rail — “Outcomes” style */}
        <div className="orb-rail">
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
                        padding:'18px 16px 10px' }}>
            <span style={{ fontSize: 13, fontWeight: 600, color:'var(--text)' }}>Pipeline</span>
            <button style={{ width: 22, height: 22, borderRadius: 5, background:'var(--surface-2)',
              border:'1px solid var(--line-strong)', color:'var(--text-2)', fontSize: 12,
              fontFamily:'inherit', cursor:'pointer', lineHeight: 1 }}>+</button>
          </div>
          <div className="orb-search">Search pipelines…</div>
          <div className="orb-rail-list" style={{ paddingTop: 4 }}>
            <RailItem active label="This week" count="5" />
            <RailItem label="Hot deals" count="6" tone="hot" />
            <RailItem label="IC review" count="3" tone="warn" />
            <RailItem label="Outbound queue" count="12" />
            <RailItem label="Awaiting refs" count="4" />
            <RailItem label="Closing soon" count="2" tone="good" />
            <RailItem label="Founder follow-ups" count="8" />
            <RailItem label="Passed (recent)" count="11" />
          </div>
        </div>

        {/* Center floating panel */}
        <div style={{ position:'relative', display:'flex', alignItems:'flex-start',
                      justifyContent:'center', padding:'24px 16px 0' }}>
          <div style={{ width: '100%', maxWidth: 540 }}>

            {/* Header bar */}
            <div style={{ display:'flex', alignItems:'center', padding:'4px 4px 16px' }}>
              <span style={{ fontSize: 11, fontWeight: 700, letterSpacing:'.16em',
                color:'var(--text-2)' }}>DEALS</span>
              <span style={{ flex: 1 }} />
              <button style={{ display:'inline-flex', alignItems:'center', gap: 4,
                background:'var(--surface-2)', border:'1px solid var(--line-strong)',
                borderRadius: 7, padding:'5px 10px', color:'var(--text)', fontSize: 11.5,
                fontFamily:'inherit', cursor:'pointer' }}>
                This week
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <path d="M6 9l6 6 6-6" /></svg>
              </button>
              <span style={{ width: 1, height: 16, background:'var(--line)', margin:'0 12px' }} />
              <button style={{ display:'inline-flex', alignItems:'center', gap: 5,
                background:'transparent', border:'none', color:'var(--text-2)', fontSize: 11.5,
                fontFamily:'inherit', cursor:'pointer' }}>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 20h9M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4z"/></svg>
                Edit
              </button>
            </div>

            {/* Item cards */}
            <div style={{ display:'flex', flexDirection:'column', gap: 12 }}>
              {items.map(it => <DealItem key={it.id} it={it} />)}
            </div>
          </div>

          {/* Footer ask bar */}
          <div style={{ position:'absolute', left: 16, right: 16, bottom: 22 }}>
            <AskBar placeholder="Type your message…" />
          </div>
        </div>

        {/* Right — Summary | Context | Modify */}
        <div style={{ borderLeft:'1px solid var(--line)', display:'flex', flexDirection:'column',
                      minHeight: 0, position:'relative' }}>
          <div style={{ padding:'14px 18px 0' }}>
            <div style={{ display:'flex', gap: 18, alignItems:'center',
                          borderBottom: '1px solid var(--line)' }}>
              <Tab2 label="Summary" />
              <Tab2 label="Context" active />
              <Tab2 label="Modify" />
              <span style={{ flex: 1 }} />
              <span style={{ color:'var(--text-3)', fontSize: 14, paddingBottom: 8, cursor:'pointer' }}>⤢</span>
            </div>
          </div>

          <div style={{ flex: 1, overflow:'auto', padding:'14px 18px 60px' }}>
            <ContextSection title="Selected">
              <div style={{ display:'flex', alignItems:'center', gap: 10, padding:'10px 12px',
                background:'var(--surface-1)', border:'1px solid var(--line)', borderRadius: 9 }}>
                <CompanyTile deal={DEALS[4]} size={28} radius={6} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color:'#fff' }}>Cipher Stack</div>
                  <div style={{ fontSize: 10.5, color:'var(--text-3)' }}>cipherstack.io</div>
                </div>
              </div>
            </ContextSection>

            <ContextSection title="Round">
              <KV k="Stage" v="Term sheet" />
              <KV k="Raising" v="$45M" mono />
              <KV k="Pre-money" v="$280M" mono />
              <KV k="Our check" v="$12M" mono />
              <KV k="Ownership" v="4.0%" mono />
              <KV k="Lead" v="Sequoia" />
            </ContextSection>

            <ContextSection title="Linked">
              <LinkedRow icon="📄" label="DD memo · v3" meta="Updated 2h ago" />
              <LinkedRow icon="✉" label="3 founder refs (logged)" meta="Maya · Karim · Aditi" />
              <LinkedRow icon="📅" label="IC slot · Apr 30 11:00" meta="3 partners confirmed" />
              <LinkedRow icon="💬" label="#dealflow channel" meta="12 messages today" />
            </ContextSection>

            <ContextSection title="Signals">
              <span className="orb-pill good" style={{ marginRight: 6, marginBottom: 6 }}><span className="dot"/>NRR 138%</span>
              <span className="orb-pill good" style={{ marginRight: 6, marginBottom: 6 }}><span className="dot"/>Sequoia lead</span>
              <span className="orb-pill warm" style={{ marginRight: 6, marginBottom: 6 }}><span className="dot"/>Late stage pricing</span>
            </ContextSection>
          </div>
        </div>
      </div>
    </div>
  );
}

function RailItem({ active, label, count, tone }) {
  const toneColor = tone === 'hot' ? 'var(--hot)' : tone === 'warn' ? 'var(--amber)'
                  : tone === 'good' ? 'var(--green)' : null;
  return (
    <div className={`orb-row ${active ? 'is-active' : ''}`}
      style={{ gridTemplateColumns:'24px 1fr auto', padding:'9px 12px' }}>
      <div className="icon" style={{ width: 18, height: 18 }}>
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none"
          stroke={toneColor || (active ? 'var(--magenta)' : 'currentColor')}
          strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          {tone === 'hot' ? <path d="M12 2c1 4 5 5 5 10a5 5 0 0 1-10 0c0-3 2-4 2-7"/> :
           tone === 'warn' ? <path d="M12 3l2.6 6 6.4.6-4.8 4.4 1.4 6.4L12 17.3 6.4 20.4l1.4-6.4L3 9.6l6.4-.6z"/> :
           tone === 'good' ? <path d="M5 12l5 5L20 7"/> :
           <path d="M3 12l4-8 5 14 4-9 5 6"/>}
        </svg>
      </div>
      <div className="title" style={{ fontSize: 12.5, fontWeight: active ? 600 : 400,
        color: active ? '#fff' : 'var(--text-2)' }}>{label}</div>
      <div className="count" style={{ color: tone ? toneColor : 'var(--text-3)' }}>{count}</div>
    </div>
  );
}

function DealItem({ it }) {
  return (
    <div className="orb-card" style={{ padding: '14px 16px', position:'relative' }}>
      <div style={{ display:'flex', alignItems:'flex-start', gap: 10 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color:'#fff', lineHeight: 1.25 }}>{it.name}</div>
        </div>
        <Pill2 label={it.status} tone={it.statusTone} chevron />
        {it.done
          ? <span style={{ width: 18, height: 18, borderRadius: '50%',
              background:'rgba(34,192,138,.2)', color:'var(--green)',
              display:'inline-flex', alignItems:'center', justifyContent:'center',
              fontSize: 10, fontWeight: 700 }}>✓</span>
          : <span style={{ width: 18, height: 18, borderRadius: '50%',
              border:'1px dashed var(--line-strong)', color:'var(--text-4)',
              display:'inline-flex', alignItems:'center', justifyContent:'center',
              fontSize: 9 }}>?</span>}
      </div>

      <div style={{ display:'flex', gap: 8, marginTop: 10 }}>
        <DatePill label={it.datePill} tone={it.dateTone} />
        <DatePill label={it.pill2} tone={it.pill2Tone} />
      </div>

      <div style={{ marginTop: 8, fontSize: 11.5, color:'var(--text-3)',
        display:'flex', alignItems:'center', gap: 6 }}>
        {it.meta}
      </div>
    </div>
  );
}

function DatePill({ label, tone }) {
  const palette = {
    magenta: { bg: 'rgba(255,45,146,.10)', bd: 'rgba(255,45,146,.28)', fg: '#ffb0d4' },
    cyan:    { bg: 'rgba(56,200,220,.10)', bd: 'rgba(56,200,220,.28)', fg: '#9ee5ee' },
  }[tone] || { bg:'rgba(255,255,255,.05)', bd:'var(--line)', fg:'var(--text-2)' };
  return (
    <span style={{
      padding:'4px 10px', borderRadius: 6, fontSize: 11.5, fontWeight: 500,
      background: palette.bg, border: `1px solid ${palette.bd}`, color: palette.fg,
      fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums',
    }}>{label}</span>
  );
}

function Pill2({ label, tone, chevron }) {
  const palette = {
    cyan:    { bg: 'rgba(56,200,220,.10)', bd: 'rgba(56,200,220,.30)', fg: '#9ee5ee' },
    magenta: { bg: 'rgba(255,45,146,.12)', bd: 'rgba(255,45,146,.30)', fg: '#ffb0d4' },
    amber:   { bg: 'rgba(245,165,36,.10)', bd: 'rgba(245,165,36,.28)', fg: '#f5c87a' },
    green:   { bg: 'rgba(34,192,138,.10)', bd: 'rgba(34,192,138,.28)', fg: '#7be0b8' },
  }[tone] || { bg:'rgba(255,255,255,.05)', bd:'var(--line)', fg:'var(--text-2)' };
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap: 4,
      padding:'3px 8px', borderRadius: 5, fontSize: 10.5, fontWeight: 600,
      background: palette.bg, border: `1px solid ${palette.bd}`, color: palette.fg,
    }}>
      {chevron && <span style={{ opacity: .7, fontSize: 10 }}>«</span>}
      {label}
    </span>
  );
}

function Tab2({ label, active }) {
  return (
    <div style={{
      paddingBottom: 8, fontSize: 12.5, fontWeight: active ? 600 : 400,
      color: active ? '#fff' : 'var(--text-3)',
      borderBottom: active ? '2px solid #5fdde6' : '2px solid transparent',
      marginBottom: -1, cursor:'pointer',
    }}>{label}</div>
  );
}

function ContextSection({ title, children }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ fontSize: 10, color:'var(--text-3)', textTransform:'uppercase',
        letterSpacing:'.08em', fontWeight: 600, marginBottom: 8 }}>{title}</div>
      {children}
    </div>
  );
}

function KV({ k, v, mono }) {
  return (
    <div style={{ display:'flex', justifyContent:'space-between', padding:'5px 0',
      borderBottom: '1px dashed var(--line)', fontSize: 11.5 }}>
      <span style={{ color:'var(--text-3)' }}>{k}</span>
      <span style={{ color:'#fff', fontWeight: 500,
        fontFamily: mono ? 'var(--mono)' : 'inherit' }}>{v}</span>
    </div>
  );
}

function LinkedRow({ icon, label, meta }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap: 10, padding:'8px 10px',
      background:'var(--surface-1)', border:'1px solid var(--line)', borderRadius: 7,
      marginBottom: 6 }}>
      <span style={{ fontSize: 13 }}>{icon}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 11.5, color:'#fff', fontWeight: 500 }}>{label}</div>
        <div style={{ fontSize: 10.5, color:'var(--text-3)' }}>{meta}</div>
      </div>
    </div>
  );
}

window.DealFlowWidget = DealFlowWidget;

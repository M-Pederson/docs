// Variation 5 — Pipeline Settings: editable custom stages
// Shows how a fund customizes their pipeline: rename, reorder, recolor,
// add automation rules per stage, set "exit criteria" for each.

function V5Settings() {
  const stages = [
    { id:'sourced',   label:'Sourced',     color:'#76767c', count: 14, criteria:'Captured contact + 1-line thesis fit', auto:'Auto-add inbound from forms' },
    { id:'firstcall', label:'First call',  color:'#5b8def', count: 9,  criteria:'30-min intro completed, notes filed', auto:'Slack ping owner after call' },
    { id:'deepdive',  label:'Deep dive',   color:'#22c08a', count: 7,  criteria:'Founder Q&A + market memo started', auto:'Create Notion DD doc', custom: true },
    { id:'diligence', label:'Diligence',   color:'#f5a524', count: 6,  criteria:'Refs + financials + tech DD complete', auto:'Reminder at day 14' },
    { id:'partner',   label:'Partner mtg', color:'#ff8a3d', count: 4,  criteria:'Sponsor + 2 partners reviewed', auto:'Calendar block, deck attached', custom: true },
    { id:'ic',        label:'IC',          color:'#ff3d8a', count: 3,  criteria:'Memo distributed 48h prior', auto:'Memo template instantiated' },
    { id:'termsheet', label:'Term sheet',  color:'#a26bff', count: 2,  criteria:'TS signed by founder',                auto:'Notify counsel + portfolio ops' },
    { id:'closed',    label:'Closed',      color:'#22c08a', count: 4,  criteria:'Wire confirmed',                       auto:'Move to portfolio CRM' },
  ];

  return (
    <div className="orb" style={{ width: 1280, height: 800, position:'relative', overflow:'hidden' }}>
      <TopNav active="dealflow" />

      <div style={{ position:'absolute', top: 44, left: 0, right: 0, bottom: 0,
                    display:'grid', gridTemplateColumns: '232px 1fr' }}>
        {/* Left rail w/ Settings */}
        <div className="orb-rail">
          <div className="orb-rail-head">Deal Flow</div>
          <div className="orb-search">Search settings…</div>
          <div className="orb-rail-list" style={{ paddingTop: 4 }}>
            <div style={{ padding:'8px 12px 4px', fontSize: 10, color:'var(--text-4)',
              textTransform:'uppercase', letterSpacing:'.08em', fontWeight: 600 }}>Pipeline</div>
            <div className="orb-row is-active" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--magenta)' }}>≡</span>
              <span className="title" style={{ fontSize: 12.5, color:'#fff', fontWeight: 600 }}>Stages</span>
              <span style={{ fontSize: 10, color:'var(--text-3)' }} className="mono">8</span>
            </div>
            <div className="orb-row" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--text-3)' }}>⊞</span>
              <span className="title" style={{ fontSize: 12.5, color:'var(--text-2)' }}>Fields & properties</span>
              <span style={{ fontSize: 10, color:'var(--text-4)' }} className="mono">23</span>
            </div>
            <div className="orb-row" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--text-3)' }}>⚡</span>
              <span className="title" style={{ fontSize: 12.5, color:'var(--text-2)' }}>Automations</span>
              <span style={{ fontSize: 10, color:'var(--text-4)' }} className="mono">12</span>
            </div>
            <div className="orb-row" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--text-3)' }}>◐</span>
              <span className="title" style={{ fontSize: 12.5, color:'var(--text-2)' }}>Permissions</span>
              <span/>
            </div>

            <div style={{ padding:'14px 12px 4px', fontSize: 10, color:'var(--text-4)',
              textTransform:'uppercase', letterSpacing:'.08em', fontWeight: 600 }}>Templates</div>
            <div className="orb-row" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--text-3)' }}>↺</span>
              <span className="title" style={{ fontSize: 12.5, color:'var(--text-2)' }}>VC standard (8 stages)</span>
              <span/>
            </div>
            <div className="orb-row" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--text-3)' }}>↺</span>
              <span className="title" style={{ fontSize: 12.5, color:'var(--text-2)' }}>Seed-only (5 stages)</span>
              <span/>
            </div>
            <div className="orb-row" style={{ gridTemplateColumns:'20px 1fr auto' }}>
              <span style={{ color:'var(--text-3)' }}>↺</span>
              <span className="title" style={{ fontSize: 12.5, color:'var(--text-2)' }}>Growth fund (10 stages)</span>
              <span/>
            </div>
          </div>
        </div>

        {/* Settings canvas */}
        <div style={{ position:'relative', overflow:'hidden', display:'flex', flexDirection:'column' }}>
          {/* Header */}
          <div style={{ padding:'18px 32px 14px', borderBottom:'1px solid var(--line)' }}>
            <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
              <div className="orb-eyebrow">PIPELINE · STAGES</div>
              <span style={{ flex: 1 }} />
              <span className="orb-pill"><span className="dot" style={{ background:'var(--green)' }} />Saved 2m ago</span>
              <button style={{ padding:'6px 12px', borderRadius: 7, background:'var(--magenta)',
                color:'#fff', border: 'none', fontSize: 12, fontWeight: 600, fontFamily:'inherit' }}>Apply to pipeline</button>
            </div>
            <div style={{ fontSize: 22, fontWeight: 600, marginTop: 6, letterSpacing: '-.01em' }}>Customize your pipeline stages</div>
            <div style={{ fontSize: 12.5, color:'var(--text-3)', marginTop: 4 }}>
              Drag to reorder. Each stage has exit criteria (what marks a deal “done” for the stage) and optional automations.
            </div>
          </div>

          {/* Two-column body: stage list + detail */}
          <div style={{ flex: 1, display:'grid', gridTemplateColumns:'1.1fr 1fr',
                        gap: 0, minHeight: 0 }}>
            {/* Stage list */}
            <div style={{ overflow:'auto', padding:'18px 32px 100px', borderRight:'1px solid var(--line)' }}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: 10 }}>
                <div style={{ fontSize: 11.5, fontWeight: 600, color:'var(--text-2)',
                  textTransform:'uppercase', letterSpacing:'.06em' }}>8 stages · 49 deals</div>
                <button style={{ background:'transparent', border:'1px dashed var(--line-strong)',
                  color:'var(--magenta)', padding:'6px 10px', borderRadius: 7, fontSize: 12,
                  fontFamily:'inherit', cursor:'pointer' }}>+ Add stage</button>
              </div>

              {stages.map((s, i) => (
                <StageEditor key={s.id} s={s} active={s.id === 'partner'} />
              ))}

              {/* Insertion affordance */}
              <div style={{ height: 8, position:'relative' }}>
                <div style={{ position:'absolute', left: 30, right: 0, top: 4, height: 1,
                  background:'rgba(255,45,146,.4)' }} />
                <div style={{ position:'absolute', left: 30, top: 0,
                  background:'var(--magenta)', color:'#fff', fontSize: 10, padding:'2px 6px',
                  borderRadius: 4, fontWeight: 600 }}>Drop here</div>
              </div>

              <button style={{ marginTop: 12, width:'100%', background:'transparent',
                border:'1px dashed var(--line-strong)', color:'var(--text-3)',
                padding:'10px 12px', borderRadius: 8, fontSize: 12, fontFamily:'inherit', cursor:'pointer' }}>
                + Add stage
              </button>
            </div>

            {/* Right: detail of selected stage */}
            <div style={{ overflow:'auto', padding:'18px 28px 80px' }}>
              <div style={{ fontSize: 11, color:'var(--text-3)', textTransform:'uppercase',
                letterSpacing:'.08em', fontWeight: 600 }}>EDITING STAGE</div>
              <div style={{ display:'flex', alignItems:'center', gap: 10, marginTop: 8 }}>
                <ColorSwatch color="#ff8a3d" active />
                <input defaultValue="Partner mtg" style={{
                  flex: 1, background:'var(--surface-1)', border:'1px solid var(--line-strong)',
                  borderRadius: 8, padding:'8px 12px', color:'#fff', fontSize: 16,
                  fontWeight: 600, fontFamily:'inherit', outline:'none' }} />
              </div>

              <div style={{ display:'flex', gap: 6, marginTop: 10, flexWrap:'wrap' }}>
                {['#ff2d92','#a26bff','#ff8a3d','#f5a524','#22c08a','#5b8def','#ef4444','#76767c'].map(c => (
                  <ColorSwatch key={c} color={c} active={c === '#ff8a3d'} small />
                ))}
              </div>

              <Field label="Description" hint="Shown to teammates as a tooltip">
                <textarea defaultValue="Pre-IC review with sponsor partner and one peer. Used to pressure-test thesis before committing IC time."
                  style={{ width:'100%', background:'var(--surface-1)', border:'1px solid var(--line)',
                  borderRadius: 8, padding: 10, color: 'var(--text)', fontSize: 12,
                  fontFamily:'inherit', minHeight: 56, resize:'none', outline:'none' }} />
              </Field>

              <Field label="Exit criteria" hint="A deal can advance only when these are checked">
                <Criterion label="Sponsor partner assigned" checked />
                <Criterion label="Two-pager memo distributed" checked />
                <Criterion label="At least 1 founder reference logged" />
                <Criterion label="Market sizing complete" />
                <button style={{ background:'transparent', border:'none', color:'var(--magenta)',
                  fontSize: 11.5, padding: '4px 0', fontFamily:'inherit', cursor:'pointer' }}>+ Add criterion</button>
              </Field>

              <Field label="Automations" hint="Run when a deal enters this stage">
                <Automation icon="🗓" text="Create calendar event with sponsor + 1 peer" on />
                <Automation icon="📎" text="Attach memo template to deal" on />
                <Automation icon="🔔" text="Slack #dealflow with 1-line summary" />
              </Field>

              <Field label="SLA">
                <div style={{ display:'flex', gap: 8 }}>
                  <SLAChip label="3 days" />
                  <SLAChip label="1 week" active />
                  <SLAChip label="2 weeks" />
                  <SLAChip label="No limit" />
                </div>
                <div style={{ fontSize: 11, color:'var(--text-3)', marginTop: 6 }}>
                  Deals stuck in <span style={{ color:'var(--amber)' }}>Partner mtg</span> for over 1 week surface in your daily brief.
                </div>
              </Field>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StageEditor({ s, active }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 10,
      padding: '10px 12px',
      background: active ? 'rgba(255,138,61,.06)' : 'var(--surface-1)',
      border: '1px solid', borderColor: active ? 'rgba(255,138,61,.35)' : 'var(--line)',
      borderRadius: 9, marginBottom: 6,
    }}>
      <span style={{ color:'var(--text-4)', cursor:'grab', fontSize: 12, lineHeight: 1 }}>⋮⋮</span>
      <span style={{ width: 10, height: 10, borderRadius: 3, background: s.color,
        boxShadow: active ? `0 0 8px ${s.color}` : 'none' }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display:'flex', alignItems:'center', gap: 8 }}>
          <span style={{ fontSize: 13, fontWeight: 600, color:'#fff' }}>{s.label}</span>
          {s.custom && <span className="orb-pill" style={{ fontSize: 9.5, padding:'2px 6px',
            color:'var(--magenta)', borderColor:'rgba(255,45,146,.3)' }}>CUSTOM</span>}
          <span className="mono" style={{ fontSize: 10.5, color:'var(--text-4)' }}>· {s.count} deals</span>
        </div>
        <div style={{ fontSize: 11, color:'var(--text-3)', marginTop: 3, lineHeight: 1.4 }}>
          <span style={{ color:'var(--text-2)' }}>Exit:</span> {s.criteria} <span style={{ color:'var(--text-4)' }}>·</span> <span style={{ color:'var(--text-3)' }}>{s.auto}</span>
        </div>
      </div>
      <button style={{ background:'transparent', border:'none', color:'var(--text-3)', fontSize: 14,
        padding: '4px 6px', cursor:'pointer' }}>⋯</button>
    </div>
  );
}

function ColorSwatch({ color, active, small }) {
  const sz = small ? 18 : 32;
  return (
    <div style={{ width: sz, height: sz, borderRadius: small ? 5 : 8, background: color,
      boxShadow: active ? `0 0 0 2px var(--bg), 0 0 0 3px ${color}` : 'none', flexShrink: 0 }} />
  );
}

function Field({ label, hint, children }) {
  return (
    <div style={{ marginTop: 18 }}>
      <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between' }}>
        <div style={{ fontSize: 11, color:'var(--text-2)', fontWeight: 600,
          textTransform:'uppercase', letterSpacing:'.06em' }}>{label}</div>
        {hint && <div style={{ fontSize: 10.5, color:'var(--text-4)' }}>{hint}</div>}
      </div>
      <div style={{ marginTop: 8 }}>{children}</div>
    </div>
  );
}

function Criterion({ label, checked }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap: 8, padding:'6px 0' }}>
      <span style={{
        width: 14, height: 14, borderRadius: 4,
        background: checked ? 'var(--magenta)' : 'transparent',
        border: '1px solid', borderColor: checked ? 'var(--magenta)' : 'var(--line-strong)',
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        color:'#fff', fontSize: 10, fontWeight: 700,
      }}>{checked ? '✓' : ''}</span>
      <span style={{ fontSize: 12, color: checked ? 'var(--text)' : 'var(--text-2)' }}>{label}</span>
    </div>
  );
}

function Automation({ icon, text, on }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap: 10, padding:'8px 10px',
      background:'var(--surface-1)', border:'1px solid var(--line)', borderRadius: 7, marginBottom: 6 }}>
      <span style={{ fontSize: 14 }}>{icon}</span>
      <span style={{ flex: 1, fontSize: 12, color:'var(--text-2)' }}>{text}</span>
      <span style={{ width: 26, height: 14, borderRadius: 7,
        background: on ? 'var(--magenta)' : 'var(--surface-3)', position:'relative', flexShrink: 0 }}>
        <span style={{ position:'absolute', top: 1, left: on ? 13 : 1, width: 12, height: 12,
          borderRadius: '50%', background:'#fff', transition:'.15s' }} />
      </span>
    </div>
  );
}

function SLAChip({ label, active }) {
  return (
    <span className="orb-pill" style={{
      cursor:'pointer',
      background: active ? 'rgba(255,45,146,.10)' : 'rgba(255,255,255,.05)',
      borderColor: active ? 'rgba(255,45,146,.35)' : 'var(--line)',
      color: active ? 'var(--magenta)' : 'var(--text-2)',
    }}>{label}</span>
  );
}

window.V5Settings = V5Settings;
